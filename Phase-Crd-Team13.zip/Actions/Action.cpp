#include "Action.h"

void Action::Undo()
{
}

void Action::Redo()
{
}
